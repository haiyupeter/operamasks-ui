﻿/*
Copyright 2011, AUTHORS.txt (http://ui.operamasks.org/about)
Dual licensed under the MIT or GPL Version 2 licenses.
*/

OMEDITOR.plugins.setLang( 'placeholder', 'he',
{
	placeholder :
	{
		title		: 'מאפייני שומר מקום',
		toolbar		: 'צור שומר מקום',
		text		: 'תוכן שומר המקום',
		edit		: 'ערוך שומר מקום',
		textMissing	: 'שומר המקום חייב להכיל טקסט.'
	}
});
