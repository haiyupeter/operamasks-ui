﻿/*
Copyright 2011, AUTHORS.txt (http://ui.operamasks.org/about)
Dual licensed under the MIT or GPL Version 2 licenses.
*/

OMEDITOR.plugins.setLang( 'devtools', 'en',
{
	devTools :
	{
		title		: 'Element Information',
		dialogName	: 'Dialog window name',
		tabName		: 'Tab name',
		elementId	: 'Element ID',
		elementType	: 'Element type'
	}
});
