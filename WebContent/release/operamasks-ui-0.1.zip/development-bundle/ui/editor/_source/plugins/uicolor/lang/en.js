﻿/*
Copyright 2011, AUTHORS.txt (http://ui.operamasks.org/about)
Dual licensed under the MIT or GPL Version 2 licenses.
*/

OMEDITOR.plugins.setLang( 'uicolor', 'en',
{
	uicolor :
	{
		title : 'UI Color Picker',
		preview : 'Live preview',
		config : 'Paste this string into your config.js file',
		predefined : 'Predefined color sets'
	}
});
